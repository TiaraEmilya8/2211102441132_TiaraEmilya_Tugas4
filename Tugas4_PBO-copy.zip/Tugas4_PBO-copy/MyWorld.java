import greenfoot.*;  

public class MyWorld extends World {
    private int currentLevel = 1;

    public MyWorld() {
        super(600, 400, 1);
        prepare();
    }

    private void prepare() {
        // Tambahkan satu hiu
        Hiu hiu = new Hiu();
        addObject(hiu, Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));

        // Tambahkan logika penempatan koin di sini (jika perlu)
        Fish fish = new Fish();
        addObject(fish,48,244);
    }

    private int frameCount = 0;
    private int CoinSpawnDelay = 100;

    public void act() {
        frameCount++;
        if (frameCount % CoinSpawnDelay == 0) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Coin(), x, y);
        }
    }
}