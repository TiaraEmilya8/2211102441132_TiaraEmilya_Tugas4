import greenfoot.*;

public class Hiu extends Actor {
    public Hiu() {
        setImage("Hiu.png");
    }

    public void act() {
        if (!isGameOver()) {
            chaseFish();
            checkEdge();
        }
    }

    public void chaseFish() {
        Fish fish = (Fish) getWorld().getObjects(Fish.class).get(0);

        if (fish != null) {
            int targetX = fish.getX();
            int targetY = fish.getY();

            int deltaX = targetX - getX();
            int deltaY = targetY - getY();

            double angle = Math.toDegrees(Math.atan2(deltaY, deltaX));
            int speed = 2;

            int dx = (int) (speed * Math.cos(Math.toRadians(angle)));
            int dy = (int) (speed * Math.sin(Math.toRadians(angle)));
            setLocation(getX() + dx, getY() + dy);
        }
    }

    public void checkEdge() {
        if (isAtEdge()) {
            getWorld().removeObject(this);
        }
    }

    public boolean isGameOver() {
        Fish fish = (Fish) getWorld().getObjects(Fish.class).get(0);
        if (fish != null && getIntersectingObjects(Fish.class).size() > 0) {
            getWorld().showText("Game Over", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            Greenfoot.stop();
            return true;
        }
        return false;
    }
}