import greenfoot.*;

public class Fish extends Actor {
    private int score = 0;
    
    public Fish() {
        setImage("Fish.png");
    }

    public void act() {
        handleMovement();
        checkForCoinCollision();
    }
    
    public void handleMovement() {
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 5);
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 5);
        }
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 5, getY());
        }
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 5, getY());
        }
    }
    
    public void checkForCoinCollision() {
        if (isTouching(Coin.class)) {
            removeTouching(Coin.class);
            increaseScore();
        }
    }
    
    public void increaseScore() {
        score += 10;
        getWorld().showText("Score: " + score, 50, 25);
    }
}