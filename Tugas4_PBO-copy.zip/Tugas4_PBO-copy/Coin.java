import greenfoot.*; 

public class Coin extends Actor {
    private GreenfootSound coinSound;

    public Coin() {
        GreenfootImage coinImage = new GreenfootImage("Coin.png");
        coinImage.scale(30, 30);
        setImage(coinImage);

        coinSound = new GreenfootSound("coinSound.wav");
    }

    public void act() {
        setLocation(getX() - 1, getY());
        checkForCollision();
        
        if (getX() < 0) {
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
        }
    }
    
    public void checkForCollision() {
        Actor fish = getOneIntersectingObject(Fish.class);
        if (fish != null) {
            Fish fishObject = (Fish) fish;
            
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
            
            coinSound.play();
        }
    }
}